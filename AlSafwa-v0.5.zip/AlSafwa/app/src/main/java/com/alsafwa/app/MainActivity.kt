package com.alsafwa.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class Role { CUSTOMER, CAPTAIN }
private enum class TripStatus(val label: String) {
    NEW("طلب جديد"), ACCEPTED("تم قبول الرحلة"), ARRIVED("الكابتن وصل"),
    ONBOARD("العميل ركب"), IN_PROGRESS("الرحلة جارية"), COMPLETED("مكتملة"), CANCELLED("ملغاة")
}

private data class Trip(
    val number: String,
    val customer: String,
    val captain: String,
    val from: String,
    val to: String,
    val price: Int,
    val status: TripStatus,
    val createdAt: Long = System.currentTimeMillis(),
    val captainArrival: String = "",
    val actualDropoff: String = ""
)

private class SafwaState(context: Context) {
    private val prefs = context.getSharedPreferences("alsafwa", Context.MODE_PRIVATE)
    var role by mutableStateOf(Role.CUSTOMER)
    var from by mutableStateOf("")
    var to by mutableStateOf("")
    var price by mutableStateOf(30)
    var customerName by mutableStateOf("عميل الصفوة")
    var captainName by mutableStateOf("كابتن الصفوة")
    var trips by mutableStateOf(loadTrips())
    var currentLocation by mutableStateOf("")
    var locationMessage by mutableStateOf("")

    private fun loadTrips(): List<Trip> {
        val raw = prefs.getString("trips", "") ?: ""
        if (raw.isBlank()) return listOf(Trip("SF-10001", "أحمد", "محمود", "القرية", "الموقف", 35, TripStatus.COMPLETED, captainArrival = "الموقف", actualDropoff = "الموقف"))
        return raw.lines().mapNotNull { line ->
            val p = line.split("|")
            if (p.size < 8) null else Trip(p[0],p[1],p[2],p[3],p[4],p[5].toIntOrNull() ?: 0,runCatching { TripStatus.valueOf(p[6]) }.getOrDefault(TripStatus.NEW),p[7].toLongOrNull() ?: System.currentTimeMillis(),p.getOrNull(8) ?: "",p.getOrNull(9) ?: "")
        }
    }

    private fun save() {
        prefs.edit().putString("trips", trips.joinToString("\n") { listOf(it.number,it.customer,it.captain,it.from,it.to,it.price,it.status.name,it.createdAt,it.captainArrival,it.actualDropoff).joinToString("|") }).apply()
    }

    fun readCurrentLocation(context: Context) {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            locationMessage = "اسمح للتطبيق بالوصول إلى الموقع أولاً."
            return
        }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        var best: Location? = null
        for (provider in providers) {
            runCatching { lm.getLastKnownLocation(provider) }.getOrNull()?.let { loc ->
                if (best == null || loc.time > best!!.time) best = loc
            }
        }
        val loc = best
        if (loc != null) {
            currentLocation = "${loc.latitude}, ${loc.longitude}"
            locationMessage = "تم تحديد موقعك الحالي."
        } else {
            locationMessage = "لم يتم العثور على موقع محفوظ. شغّل GPS وانتظر قليلًا ثم جرّب مرة أخرى."
        }
    }

    fun requestTrip() {
        if (from.isBlank() || to.isBlank()) return
        val next = (trips.mapNotNull { it.number.removePrefix("SF-").toIntOrNull() }.maxOrNull() ?: 10000) + 1
        trips = listOf(Trip("SF-$next", customerName, "بانتظار كابتن", from.trim(), to.trim(), price, TripStatus.NEW)) + trips
        from = ""; to = ""; save()
    }

    fun update(number: String, status: TripStatus, captain: String? = null, arrival: String? = null, dropoff: String? = null) {
        trips = trips.map { if (it.number == number) it.copy(status = status, captain = captain ?: it.captain, captainArrival = arrival ?: it.captainArrival, actualDropoff = dropoff ?: it.actualDropoff) else it }
        save()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SafwaApp() }
    }
}

@Composable
fun SafwaApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val state = remember { SafwaState(context) }
    MaterialTheme {
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("الصفوة", fontWeight = FontWeight.ExtraBold) }) }) { pad ->
                Column(Modifier.padding(pad).fillMaxSize()) {
                    RoleTabs(state)
                    when (state.role) {
                        Role.CUSTOMER -> CustomerHome(state)
                        Role.CAPTAIN -> CaptainHome(state)
                    }
                }
            }
        }
    }
}

@Composable private fun RoleTabs(state: SafwaState) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (state.role == Role.CUSTOMER) Button(Modifier.weight(1f), onClick = {}) { Text("عميل") } else OutlinedButton(Modifier.weight(1f), onClick = { state.role = Role.CUSTOMER }) { Text("عميل") }
        if (state.role == Role.CAPTAIN) Button(Modifier.weight(1f), onClick = {}) { Text("كابتن") } else OutlinedButton(Modifier.weight(1f), onClick = { state.role = Role.CAPTAIN }) { Text("كابتن") }
    }
}

@Composable private fun CustomerHome(state: SafwaState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        state.readCurrentLocation(context)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Text("اطلب توك توك", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("حدد البداية والوجهة، واقترح السعر الذي يناسبك.", style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }, Modifier.fillMaxWidth()) { Text("تحديد موقعي الحالي") }
        if (state.currentLocation.isNotBlank()) Text("موقعي: ${state.currentLocation}", style = MaterialTheme.typography.bodySmall)
        if (state.locationMessage.isNotBlank()) Text(state.locationMessage, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(state.customerName, { state.customerName = it }, Modifier.fillMaxWidth(), label = { Text("اسم العميل") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(state.from, { state.from = it }, Modifier.fillMaxWidth(), label = { Text("مكان البداية") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(state.to, { state.to = it }, Modifier.fillMaxWidth(), label = { Text("الوجهة") })
        Spacer(Modifier.height(12.dp))
        Text("السعر المقترح: ${state.price} جنيه", fontWeight = FontWeight.Bold)
        Slider(state.price.toFloat(), { state.price = it.toInt() }, valueRange = 10f..300f, steps = 28)
        Button(onClick = { state.requestTrip() }, Modifier.fillMaxWidth().height(52.dp), enabled = state.from.isNotBlank() && state.to.isNotBlank()) { Text("اطلب الرحلة", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(20.dp))
        SectionTitle("رحلاتي")
        state.trips.forEach { TripCard(it, state, false) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable private fun CaptainHome(state: SafwaState) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        state.readCurrentLocation(context)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Text("لوحة الكابتن", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(state.captainName, { state.captainName = it }, Modifier.fillMaxWidth(), label = { Text("اسم الكابتن") })
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = {
            permissionLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }, Modifier.fillMaxWidth()) { Text("تحديث موقع الكابتن") }
        if (state.currentLocation.isNotBlank()) Text("موقع الكابتن: ${state.currentLocation}", style = MaterialTheme.typography.bodySmall)
        if (state.locationMessage.isNotBlank()) Text(state.locationMessage, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(10.dp))
        val requests = state.trips.filter { it.status == TripStatus.NEW }
        SectionTitle("الطلبات المتاحة (${requests.size})")
        if (requests.isEmpty()) Text("لا توجد طلبات جديدة حاليًا.")
        requests.forEach { TripCard(it, state, true) }
        Spacer(Modifier.height(14.dp))
        SectionTitle("رحلاتي الحالية")
        state.trips.filter { it.captain == state.captainName && it.status !in listOf(TripStatus.COMPLETED, TripStatus.CANCELLED) }.forEach { TripCard(it, state, true) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable private fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp)) }

@Composable private fun TripCard(t: Trip, state: SafwaState, captainMode: Boolean) {
    Card(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(t.number, fontWeight = FontWeight.Bold)
                AssistChip(onClick = {}, label = { Text(t.status.label) })
            }
            Text("من: ${t.from}")
            Text("إلى: ${t.to}")
            Text("السعر: ${t.price} جنيه")
            Text("العميل: ${t.customer}")
            Text("الكابتن: ${t.captain}")
            Text("وقت الطلب: ${SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(t.createdAt))}")
            if (t.captainArrival.isNotBlank()) Text("وصول الكابتن: ${t.captainArrival}")
            if (t.actualDropoff.isNotBlank()) Text("النزول الفعلي: ${t.actualDropoff}")

            if (captainMode && t.status == TripStatus.NEW) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = { state.update(t.number, TripStatus.ACCEPTED, state.captainName) }, Modifier.fillMaxWidth()) { Text("قبول الرحلة") }
            }
            if (captainMode && t.status == TripStatus.ACCEPTED) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = { state.update(t.number, TripStatus.ARRIVED, arrival = if (state.currentLocation.isBlank()) t.from else state.currentLocation) }, Modifier.fillMaxWidth()) { Text("تأكيد الوصول") }
            }
            if (captainMode && t.status == TripStatus.ARRIVED) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = { state.update(t.number, TripStatus.ONBOARD) }, Modifier.fillMaxWidth()) { Text("تأكيد ركوب العميل") }
            }
            if (captainMode && t.status == TripStatus.ONBOARD) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = { state.update(t.number, TripStatus.IN_PROGRESS) }, Modifier.fillMaxWidth()) { Text("بدء الرحلة") }
            }
            if (captainMode && t.status == TripStatus.IN_PROGRESS) {
                Spacer(Modifier.height(8.dp))
                Button(onClick = { state.update(t.number, TripStatus.COMPLETED, dropoff = if (state.currentLocation.isBlank()) t.to else state.currentLocation) }, Modifier.fillMaxWidth()) { Text("إنهاء الرحلة وتسجيل النزول") }
            }
        }
    }
}
