# الصفوة — بناء APK

## من GitHub
1. ارفع مجلد `AlSafwa` إلى مستودع GitHub.
2. افتح تبويب **Actions**.
3. شغّل **Build AlSafwa APK**.
4. بعد نجاح البناء، افتح نتيجة التشغيل وحمّل artifact باسم `AlSafwa-debug-apk`.

الإصدار الحالي: **0.4.0**.
